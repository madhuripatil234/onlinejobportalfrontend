import axios from "axios";

class Contactservice {
    saveContact(contData){
        let promise=axios.post("http://localhost:3000/contactpage",contData);
        return promise;
    }
    adminLogin(Data){
        let promise=axios.post("http://localhost:3000/loginadmin",Data);
        return promise;
    }
    hrLogin(hrData){
        let promise=axios.post("http://localhost:3000/hrlog",hrData);
        return promise;
    }
     userLogin(uData){
        let promise=axios.post("http://localhost:3000/loginuser",uData);
        return promise;
    }

}
export default new Contactservice();







